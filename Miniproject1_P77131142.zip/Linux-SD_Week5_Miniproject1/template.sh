#!/bin/bash

cp student_id missing_list
touch wrong_list

filenames=$(ls compressed_files/)
studet_id=$(cat student_id)

# find the student id of missing list
for filename in $filenames; do
    # Write your code here
done


mkdir compressed_files/zip
mkdir compressed_files/rar
mkdir compressed_files/tar.gz
mkdir compressed_files/unknown

# classify the compressed files into the three directories (zip, rar, tar.gz)
# Write your code here

cd compressed_files
# classify the unknown files
# write your code here

# uncompress all .tar.gz files
cd tar.gz 
filenames=$(ls)
for filename in $filenames;do
    # Write your code here
done
cd ..

# uncompress all .zip files
cd zip
filenames=$(ls)
for filename in $filenames;do
    # Write your code here
done
cd ..

# uncompress all .rar files
cd rar
filenames=$(ls)
for filename in $filenames;do
    # Write your code here
done
cd ../..

# find the student id of wrong_list
filenames=$(ls compressed_files/unknown)
for filename in $filenames; do
    # Write your code here
done
