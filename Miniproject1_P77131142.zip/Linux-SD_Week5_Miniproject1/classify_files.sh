# classification by file extension
# zip/ tar.gz/ rar/

# check directory exist
if [[ ! -d compressed_files ]]; then 
    echo "directory compressed_files/ not exist!!"
    exit 1
fi

cd compressed_files

# create directory if not exist
mkdir -p zip rar "tar.gz" unknow

echo "start classify..."

for file in *; do
    # check if it is file not dir
    [[ -f "$file" ]] || continue

    # if zip move to zip/
    case "$file" in
        *.zip)
          mv -n -- "$file" zip/
          ;;
        *.tar.gz)
          mv -n -- "$file" "tar.gz"/
          ;;
        *.rar)
          mv -n -- "$file" rar/
          ;;
        *)
          mv -n -- "$file" unknow/
          ;;
    esac
done

echo "done!"
