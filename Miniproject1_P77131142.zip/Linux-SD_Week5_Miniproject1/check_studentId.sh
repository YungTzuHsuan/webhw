# check if every student id in compressed_list/ if not copy into missing_list
# check if file in zip tar.gz or rar if not copy into wrong_list

# clear file
:>missing_list
:>wrong_list

# check directory exist -d=dir
if [[ ! -d compressed_files ]]; then
    echo "directory compressed_files/ not exist!!"
    exit 1
fi

echo "check student_id..."

# read student_id
while IFS= read -r student || [[ -n "$student" ]]; do
    # remove \r\n and blank
    student=$(echo "$student" | tr -d '\r\n' | xargs)
    [[ -z "$student" ]] && continue

    # find if dir has any start with student id 
    found=$(ls compressed_files/"${student}"* 2>/dev/null || true)

    # not found
    if [[ -z "$found" ]]; then
        echo "$student" >> missing_list
    # found id
    else
        # check file
        case "$found" in
          *.zip | *.tar.gz | *.rar)
            # do nothing
            ;;
        *)
            # wrong file
            echo "$student" >> wrong_list
            ;;
        esac
    fi
done < student_id

echo "done!"
